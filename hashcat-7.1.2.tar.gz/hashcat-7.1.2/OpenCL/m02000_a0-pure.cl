/**
 * Author......: See docs/credits.txt
 * License.....: MIT
 */

#ifdef KERNEL_STATIC
#include M2S(INCLUDE_PATH/inc_vendor.h)
#include M2S(INCLUDE_PATH/inc_types.h)
#include M2S(INCLUDE_PATH/inc_platform.cl)
#include M2S(INCLUDE_PATH/inc_common.cl)
#endif

KERNEL_FQ KERNEL_FA void m02000_mxx (KERN_ATTR_RULES ())
{
}

KERNEL_FQ KERNEL_FA void m02000_sxx (KERN_ATTR_RULES ())
{
}
